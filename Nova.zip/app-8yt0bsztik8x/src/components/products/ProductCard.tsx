import { Link } from 'react-router-dom';
import { Star, Heart } from 'lucide-react';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { Product } from '@/types';
import { cn } from '@/lib/utils';

interface ProductCardProps {
  product: Product;
  onAddToCart?: (product: Product) => void;
  onToggleWishlist?: (product: Product) => void;
  isInWishlist?: boolean;
}

export function ProductCard({ product, onAddToCart, onToggleWishlist, isInWishlist }: ProductCardProps) {
  const imageUrl = product.images?.[0] || 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=800';
  
  // Check if product is new (created within last 30 days)
  const isNew = product.created_at && 
    new Date(product.created_at).getTime() > Date.now() - 30 * 24 * 60 * 60 * 1000;
  
  // Check if product has high rating (4.5+)
  const isTopRated = product.rating >= 4.5;
  
  // Check if product is on sale (random for demo)
  const isOnSale = product.id.charCodeAt(0) % 3 === 0;

  return (
    <Card className="group overflow-hidden card-hover border-border/50 bg-card/50 backdrop-blur-sm">
      <Link to={`/products/${product.id}`}>
        <div className="relative aspect-square overflow-hidden bg-gradient-to-br from-muted to-accent/20">
          <img
            src={imageUrl}
            alt={product.name}
            className="object-cover w-full h-full group-hover:scale-110 transition-transform duration-500 ease-out"
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
          
          {/* Top Left Badges */}
          <div className="absolute top-2 left-2 flex flex-col gap-1">
            {product.stock === 0 && (
              <Badge className="shadow-lg text-xs" variant="destructive">
                Out of Stock
              </Badge>
            )}
            {product.stock > 0 && product.stock < 10 && (
              <Badge className="shadow-lg bg-secondary text-secondary-foreground text-xs">
                Only {product.stock} left
              </Badge>
            )}
            {isNew && product.stock > 0 && (
              <Badge className="shadow-lg bg-primary text-primary-foreground text-xs animate-pulse">
                ⚡ New
              </Badge>
            )}
            {isOnSale && product.stock > 0 && (
              <Badge className="shadow-lg bg-destructive text-destructive-foreground text-xs">
                🔥 Sale
              </Badge>
            )}
          </div>
          
          {/* Top Right Badge */}
          {isTopRated && (
            <Badge className="absolute top-2 right-12 shadow-lg bg-warning text-warning-foreground text-xs">
              ⭐ Top Rated
            </Badge>
          )}
          
          <Button
            variant="ghost"
            size="icon"
            className="absolute top-2 right-2 h-8 w-8 bg-background/80 backdrop-blur-sm hover:bg-background opacity-0 group-hover:opacity-100 transition-opacity duration-300"
            onClick={(e) => {
              e.preventDefault();
              onToggleWishlist?.(product);
            }}
          >
            <Heart className={cn('h-3.5 w-3.5', isInWishlist && 'fill-destructive text-destructive')} />
          </Button>
        </div>
      </Link>
      <CardContent className="p-3">
        <Link to={`/products/${product.id}`}>
          <h3 className="font-semibold text-base line-clamp-2 mb-1.5 hover:text-primary transition-colors duration-200">
            {product.name}
          </h3>
        </Link>
        <p className="text-xs text-muted-foreground mb-2 font-medium">{product.brand}</p>
        <div className="flex items-center gap-1.5 mb-2">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className={cn(
                  'h-3 w-3 transition-colors',
                  i < Math.floor(product.rating)
                    ? 'fill-warning text-warning'
                    : 'fill-muted text-muted-foreground/30'
                )}
              />
            ))}
          </div>
          <span className="text-xs text-muted-foreground font-medium">
            {product.rating.toFixed(1)} ({product.review_count})
          </span>
        </div>
        <div className="flex items-baseline gap-1.5 mb-2">
          <span className="text-2xl font-bold bg-gradient-primary bg-clip-text text-transparent">
            ${product.price.toFixed(2)}
          </span>
          {isOnSale && (
            <span className="text-xs text-muted-foreground line-through">
              ${(product.price * 1.25).toFixed(2)}
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-3 pt-0 flex gap-2">
        <Button
          className="flex-1 h-9 text-sm shadow-sm hover:shadow-md transition-shadow"
          onClick={() => onAddToCart?.(product)}
          disabled={product.stock === 0}
        >
          Add to Cart
        </Button>
      </CardFooter>
    </Card>
  );
}
