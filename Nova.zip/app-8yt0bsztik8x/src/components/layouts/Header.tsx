import { Link, useLocation } from 'react-router-dom';
import { ShoppingCart, Search, User, Menu, Heart, Package, LogOut, Settings, Store } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/contexts/AuthContext';
import { useState, useEffect } from 'react';
import { getCartItems } from '@/db/api';
import { useNavigate } from 'react-router-dom';

export function Header() {
  const { user, profile, signOut } = useAuth();
  const [cartCount, setCartCount] = useState(0);
  const [searchQuery, setSearchQuery] = useState('');
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    if (user) {
      getCartItems(user.id).then(items => {
        setCartCount(items.reduce((sum, item) => sum + item.quantity, 0));
      }).catch(() => setCartCount(0));
    } else {
      setCartCount(0);
    }
  }, [user, location.pathname]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('/');
  };

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur-md supports-[backdrop-filter]:bg-background/80 shadow-sm">
      <div className="container flex h-16 items-center gap-4 px-4">
        {/* Mobile Menu */}
        <Sheet>
          <SheetTrigger asChild className="xl:hidden">
            <Button variant="ghost" size="icon" className="hover:bg-primary/10">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="w-64 p-0">
            <MobileSidebar />
          </SheetContent>
        </Sheet>

        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2 group">
          <div className="h-9 w-9 rounded-xl bg-gradient-primary flex items-center justify-center shadow-md group-hover:shadow-lg transition-shadow">
            <span className="text-primary-foreground font-bold text-xl">N</span>
          </div>
          <span className="font-bold text-xl gradient-text hidden sm:inline-block">NovaShop</span>
        </Link>

        {/* Search Bar */}
        <form onSubmit={handleSearch} className="flex-1 max-w-xl hidden md:flex">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search products..."
              className="pl-10 pr-4 border-border/50 focus:border-primary/50 transition-colors"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>
        </form>

        {/* Actions */}
        <div className="flex items-center gap-2">
          {/* Mobile Search */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden hover:bg-primary/10"
            onClick={() => navigate('/search')}
          >
            <Search className="h-5 w-5" />
          </Button>

          {/* Cart */}
          <Button
            variant="ghost"
            size="icon"
            className="relative hover:bg-primary/10 transition-colors"
            onClick={() => navigate('/cart')}
          >
            <ShoppingCart className="h-5 w-5" />
            {cartCount > 0 && (
              <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs bg-secondary text-secondary-foreground shadow-md animate-pulse">
                {cartCount}
              </Badge>
            )}
          </Button>

          {/* User Menu */}
          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="hover:bg-primary/10">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 shadow-lg">
                <div className="px-2 py-2 bg-muted/50 rounded-t-md">
                  <p className="text-sm font-semibold">{profile?.username}</p>
                  <p className="text-xs text-muted-foreground capitalize">{profile?.role}</p>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => navigate('/profile')} className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  Profile
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/orders')} className="cursor-pointer">
                  <Package className="mr-2 h-4 w-4" />
                  Orders
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => navigate('/wishlist')} className="cursor-pointer">
                  <Heart className="mr-2 h-4 w-4" />
                  Wishlist
                </DropdownMenuItem>
                {(profile?.role === 'seller' || profile?.role === 'admin') && (
                  <>
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => navigate('/seller')} className="cursor-pointer">
                      <Store className="mr-2 h-4 w-4" />
                      Seller Dashboard
                    </DropdownMenuItem>
                  </>
                )}
                {profile?.role === 'admin' && (
                  <DropdownMenuItem onClick={() => navigate('/admin')} className="cursor-pointer">
                    <Settings className="mr-2 h-4 w-4" />
                    Admin Panel
                    </DropdownMenuItem>
                )}
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={handleSignOut}>
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Button onClick={() => navigate('/login')}>Sign In</Button>
          )}
        </div>
      </div>
    </header>
  );
}

function MobileSidebar() {
  const navigate = useNavigate();
  const { user, profile } = useAuth();

  const categories = [
    { name: 'Electronics', slug: 'electronics', icon: '⚡' },
    { name: 'Audio', slug: 'audio', icon: '🎧' },
    { name: 'Computers', slug: 'computers', icon: '💻' },
    { name: 'Wearables', slug: 'wearables', icon: '⌚' },
    { name: 'Gaming', slug: 'gaming', icon: '🎮' },
    { name: 'Accessories', slug: 'accessories', icon: '🔌' },
    { name: 'Smart Home', slug: 'smart-home', icon: '🏠' },
    { name: 'Photography', slug: 'photography', icon: '📷' },
    { name: 'Fitness', slug: 'fitness', icon: '💪' },
    { name: 'Home Appliances', slug: 'home-appliances', icon: '🏡' },
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="p-4 border-b">
        <h2 className="font-semibold text-lg">Categories</h2>
      </div>
      <div className="flex-1 overflow-auto p-2">
        {categories.map((category) => (
          <Button
            key={category.slug}
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate(`/products?category=${category.slug}`)}
          >
            <span className="mr-2">{category.icon}</span>
            {category.name}
          </Button>
        ))}
      </div>
      {user && (
        <div className="p-2 border-t">
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate('/profile')}
          >
            <User className="mr-2 h-4 w-4" />
            Profile
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate('/orders')}
          >
            <Package className="mr-2 h-4 w-4" />
            Orders
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start"
            onClick={() => navigate('/wishlist')}
          >
            <Heart className="mr-2 h-4 w-4" />
            Wishlist
          </Button>
          {(profile?.role === 'seller' || profile?.role === 'admin') && (
            <Button
              variant="ghost"
              className="w-full justify-start"
              onClick={() => navigate('/seller')}
            >
              <Store className="mr-2 h-4 w-4" />
              Seller Dashboard
            </Button>
          )}
        </div>
      )}
    </div>
  );
}
