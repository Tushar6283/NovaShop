import { useNavigate, useLocation } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

export function Sidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const categories = [
    { name: 'All Products', slug: '', icon: '🛍️' },
    { name: 'Electronics', slug: 'electronics', icon: '⚡' },
    { name: 'Audio', slug: 'audio', icon: '🎧' },
    { name: 'Computers', slug: 'computers', icon: '💻' },
    { name: 'Wearables', slug: 'wearables', icon: '⌚' },
    { name: 'Gaming', slug: 'gaming', icon: '🎮' },
    { name: 'Accessories', slug: 'accessories', icon: '🔌' },
    { name: 'Smart Home', slug: 'smart-home', icon: '🏠' },
    { name: 'Photography', slug: 'photography', icon: '📷' },
    { name: 'Fitness', slug: 'fitness', icon: '💪' },
    { name: 'Home Appliances', slug: 'home-appliances', icon: '🏡' },
  ];

  const isActive = (slug: string) => {
    const params = new URLSearchParams(location.search);
    const currentCategory = params.get('category');
    return slug === '' ? !currentCategory : currentCategory === slug;
  };

  return (
    <aside className="hidden xl:block w-64 shrink-0 border-r bg-sidebar">
      <ScrollArea className="h-[calc(100vh-4rem)]">
        <div className="p-4">
          <h2 className="font-semibold text-lg mb-4 text-sidebar-foreground">Categories</h2>
          <div className="space-y-1">
            {categories.map((category) => (
              <Button
                key={category.slug}
                variant={isActive(category.slug) ? 'secondary' : 'ghost'}
                className={cn(
                  'w-full justify-start',
                  isActive(category.slug) && 'bg-sidebar-accent text-sidebar-accent-foreground'
                )}
                onClick={() => {
                  if (category.slug) {
                    navigate(`/products?category=${category.slug}`);
                  } else {
                    navigate('/products');
                  }
                }}
              >
                <span className="mr-2 text-lg">{category.icon}</span>
                <span className="text-sm">{category.name}</span>
              </Button>
            ))}
          </div>

          <div className="mt-8 p-4 rounded-lg bg-sidebar-accent">
            <h3 className="font-semibold text-sm mb-2 text-sidebar-accent-foreground">Special Offers</h3>
            <p className="text-xs text-sidebar-accent-foreground/80 mb-3">
              Get up to 30% off on selected items this week!
            </p>
            <Button size="sm" className="w-full" onClick={() => navigate('/products')}>
              Shop Now
            </Button>
          </div>
        </div>
      </ScrollArea>
    </aside>
  );
}
