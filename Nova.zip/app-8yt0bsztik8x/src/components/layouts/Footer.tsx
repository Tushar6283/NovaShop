import { Link, useNavigate } from 'react-router-dom';
import { Facebook, Twitter, Instagram, Youtube, Home, ShoppingBag, Package, HeadphonesIcon, Store, Mail } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { useState } from 'react';
import { toast } from 'sonner';

export function Footer() {
  const [email, setEmail] = useState('');
  const navigate = useNavigate();

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      toast.success('Successfully subscribed to newsletter!');
      setEmail('');
    }
  };

  // Key action handlers with navigation
  const handleHomeClick = () => {
    navigate('/');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBrowseClick = () => {
    navigate('/products');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOrdersClick = () => {
    navigate('/orders');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSupportClick = () => {
    navigate('/support');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSellClick = () => {
    navigate('/seller');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleContactClick = () => {
    navigate('/contact');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t bg-muted/30">
      {/* Key Action Buttons Section */}
      <div className="border-b bg-card/50">
        <div className="container px-4 py-8">
          <h3 className="text-lg font-semibold mb-6 text-center">Quick Actions</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
            <Button
              onClick={handleHomeClick}
              variant="outline"
              className="h-auto py-4 flex flex-col items-center gap-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
            >
              <Home className="h-5 w-5 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">Home</span>
            </Button>
            
            <Button
              onClick={handleBrowseClick}
              variant="outline"
              className="h-auto py-4 flex flex-col items-center gap-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
            >
              <ShoppingBag className="h-5 w-5 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">Browse Products</span>
            </Button>
            
            <Button
              onClick={handleOrdersClick}
              variant="outline"
              className="h-auto py-4 flex flex-col items-center gap-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
            >
              <Package className="h-5 w-5 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">Orders</span>
            </Button>
            
            <Button
              onClick={handleSupportClick}
              variant="outline"
              className="h-auto py-4 flex flex-col items-center gap-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
            >
              <HeadphonesIcon className="h-5 w-5 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">Customer Support</span>
            </Button>
            
            <Button
              onClick={handleSellClick}
              variant="outline"
              className="h-auto py-4 flex flex-col items-center gap-2 hover:bg-secondary hover:text-secondary-foreground hover:border-secondary transition-all duration-300 group"
            >
              <Store className="h-5 w-5 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">Sell</span>
            </Button>
            
            <Button
              onClick={handleContactClick}
              variant="outline"
              className="h-auto py-4 flex flex-col items-center gap-2 hover:bg-primary hover:text-primary-foreground hover:border-primary transition-all duration-300 group"
            >
              <Mail className="h-5 w-5 group-hover:scale-110 transition-transform" />
              <span className="text-sm font-medium">Contact Us</span>
            </Button>
          </div>
        </div>
      </div>

      <div className="container px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="xl:col-span-1">
            <Link to="/" className="flex items-center space-x-2 mb-4">
              <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
                <span className="text-primary-foreground font-bold text-lg">N</span>
              </div>
              <span className="font-bold text-xl gradient-text">NovaShop</span>
            </Link>
            <p className="text-sm text-muted-foreground mb-4 max-w-sm">
              Your trusted destination for premium electronics and tech products. Shop with confidence and enjoy fast, reliable delivery.
            </p>
            <div className="flex gap-2">
              <Button variant="ghost" size="icon" asChild>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                  <Facebook className="h-5 w-5" />
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                  <Twitter className="h-5 w-5" />
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                  <Instagram className="h-5 w-5" />
                </a>
              </Button>
              <Button variant="ghost" size="icon" asChild>
                <a href="https://youtube.com" target="_blank" rel="noopener noreferrer">
                  <Youtube className="h-5 w-5" />
                </a>
              </Button>
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-semibold mb-4">Categories</h3>
            <ul className="space-y-2.5 text-sm">
              <li>
                <Link 
                  to="/products?category=electronics" 
                  className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Electronics</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/products?category=fashion" 
                  className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Fashion</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/products?category=home" 
                  className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Home & Living</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/products?category=beauty" 
                  className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Beauty & Health</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/products?category=sports" 
                  className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Sports & Outdoors</span>
                </Link>
              </li>
              <li>
                <Link 
                  to="/products?category=toys" 
                  className="text-muted-foreground hover:text-primary transition-colors inline-flex items-center group"
                >
                  <span className="group-hover:translate-x-1 transition-transform">Toys & Games</span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Shop */}
          <div>
            <h3 className="font-semibold mb-4">Shop</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/products" className="text-muted-foreground hover:text-foreground transition-colors">All Products</Link></li>
              <li><Link to="/products?category=electronics" className="text-muted-foreground hover:text-foreground transition-colors">Electronics</Link></li>
              <li><Link to="/products?category=audio" className="text-muted-foreground hover:text-foreground transition-colors">Audio</Link></li>
              <li><Link to="/products?category=gaming" className="text-muted-foreground hover:text-foreground transition-colors">Gaming</Link></li>
              <li><Link to="/products?category=wearables" className="text-muted-foreground hover:text-foreground transition-colors">Wearables</Link></li>
            </ul>
          </div>

          {/* Customer Service */}
          <div>
            <h3 className="font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/support" className="text-muted-foreground hover:text-foreground transition-colors">Contact Us</Link></li>
              <li><Link to="/shipping" className="text-muted-foreground hover:text-foreground transition-colors">Shipping Information</Link></li>
              <li><Link to="/returns" className="text-muted-foreground hover:text-foreground transition-colors">Returns & Exchanges</Link></li>
              <li><Link to="/orders" className="text-muted-foreground hover:text-foreground transition-colors">Track Order</Link></li>
              <li><Link to="/support" className="text-muted-foreground hover:text-foreground transition-colors">FAQ</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h3 className="font-semibold mb-4">Company</h3>
            <ul className="space-y-2 text-sm">
              <li><Link to="/about" className="text-muted-foreground hover:text-foreground transition-colors">About Us</Link></li>
              <li><Link to="/contact" className="text-muted-foreground hover:text-foreground transition-colors">Contact</Link></li>
              <li><Link to="/terms" className="text-muted-foreground hover:text-foreground transition-colors">Terms & Conditions</Link></li>
              <li><Link to="/privacy" className="text-muted-foreground hover:text-foreground transition-colors">Privacy Policy</Link></li>
              <li><Link to="/seller" className="text-muted-foreground hover:text-foreground transition-colors">Become a Seller</Link></li>
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 pt-8 border-t">
          <div className="max-w-md mx-auto text-center">
            <h3 className="font-semibold text-lg mb-2">Subscribe to our newsletter</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Get the latest updates on new products and exclusive offers.
            </p>
            <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
              <Input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="border-border/50 focus:border-primary/50 transition-colors"
              />
              <Button type="submit" className="shadow-sm hover:shadow-md transition-shadow">
                Subscribe
              </Button>
            </form>
          </div>
        </div>

        <Separator className="my-8" />

        {/* Copyright */}
        <div className="text-center text-sm text-muted-foreground">
          <p>© 2026 NovaShop. All rights reserved.</p>
          <p className="mt-2">Built with ❤️ for amazing shopping experiences</p>
        </div>
      </div>
    </footer>
  );
}
