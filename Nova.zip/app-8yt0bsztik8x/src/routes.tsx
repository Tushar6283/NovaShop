import HomePage from './pages/HomePage';
import ProductListPage from './pages/ProductListPage';
import ProductDetailPage from './pages/ProductDetailPage';
import CartPage from './pages/CartPage';
import WishlistPage from './pages/WishlistPage';
import OrdersPage from './pages/OrdersPage';
import LoginPage from './pages/LoginPage';
import ProfilePage from './pages/ProfilePage';
import SellerDashboardPage from './pages/SellerDashboardPage';
import AdminPage from './pages/AdminPage';
import SearchPage from './pages/SearchPage';
import SupportPage from './pages/SupportPage';
import AboutPage from './pages/AboutPage';
import ContactPage from './pages/ContactPage';
import TermsPage from './pages/TermsPage';
import PrivacyPage from './pages/PrivacyPage';
import ShippingPage from './pages/ShippingPage';
import ReturnsPage from './pages/ReturnsPage';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  { name: 'Home', path: '/', element: <HomePage /> },
  { name: 'Products', path: '/products', element: <ProductListPage /> },
  { name: 'Product Detail', path: '/products/:id', element: <ProductDetailPage /> },
  { name: 'Cart', path: '/cart', element: <CartPage /> },
  { name: 'Wishlist', path: '/wishlist', element: <WishlistPage /> },
  { name: 'Orders', path: '/orders', element: <OrdersPage /> },
  { name: 'Login', path: '/login', element: <LoginPage /> },
  { name: 'Profile', path: '/profile', element: <ProfilePage /> },
  { name: 'Seller Dashboard', path: '/seller', element: <SellerDashboardPage /> },
  { name: 'Admin', path: '/admin', element: <AdminPage /> },
  { name: 'Search', path: '/search', element: <SearchPage /> },
  { name: 'Support', path: '/support', element: <SupportPage /> },
  { name: 'About', path: '/about', element: <AboutPage /> },
  { name: 'Contact', path: '/contact', element: <ContactPage /> },
  { name: 'Terms', path: '/terms', element: <TermsPage /> },
  { name: 'Privacy', path: '/privacy', element: <PrivacyPage /> },
  { name: 'Shipping', path: '/shipping', element: <ShippingPage /> },
  { name: 'Returns', path: '/returns', element: <ReturnsPage /> },
];

export default routes;
