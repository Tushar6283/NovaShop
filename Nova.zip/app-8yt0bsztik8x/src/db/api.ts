import { supabase } from './supabase';
import type {
  Profile,
  Category,
  Product,
  CartItem,
  WishlistItem,
  Order,
  OrderItem,
  Review,
  SupportTicket,
  TicketStatus,
} from '@/types';

// ============ Profiles ============
export const getProfile = async (userId: string) => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', userId)
    .maybeSingle();
  
  if (error) throw error;
  return data as Profile | null;
};

export const updateProfile = async (userId: string, updates: Partial<Profile>) => {
  const { data, error } = await supabase
    .from('profiles')
    .update(updates)
    .eq('id', userId)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Profile;
};

export const getAllProfiles = async () => {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// ============ Categories ============
export const getCategories = async () => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .order('name');
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getCategoryBySlug = async (slug: string) => {
  const { data, error } = await supabase
    .from('categories')
    .select('*')
    .eq('slug', slug)
    .maybeSingle();
  
  if (error) throw error;
  return data as Category | null;
};

// ============ Products ============
export const getProducts = async (params?: {
  category?: string;
  search?: string;
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  brand?: string;
  sortBy?: 'price_asc' | 'price_desc' | 'rating' | 'newest';
  limit?: number;
  offset?: number;
}) => {
  let query = supabase.from('products').select('*', { count: 'exact' });

  if (params?.category) {
    const category = await getCategoryBySlug(params.category);
    if (category) {
      query = query.eq('category_id', category.id);
    }
  }

  if (params?.search) {
    query = query.or(`name.ilike.%${params.search}%,description.ilike.%${params.search}%,brand.ilike.%${params.search}%`);
  }

  if (params?.minPrice !== undefined) {
    query = query.gte('price', params.minPrice);
  }

  if (params?.maxPrice !== undefined) {
    query = query.lte('price', params.maxPrice);
  }

  if (params?.minRating !== undefined) {
    query = query.gte('rating', params.minRating);
  }

  if (params?.brand) {
    query = query.eq('brand', params.brand);
  }

  // Sorting
  switch (params?.sortBy) {
    case 'price_asc':
      query = query.order('price', { ascending: true });
      break;
    case 'price_desc':
      query = query.order('price', { ascending: false });
      break;
    case 'rating':
      query = query.order('rating', { ascending: false });
      break;
    case 'newest':
      query = query.order('created_at', { ascending: false });
      break;
    default:
      query = query.order('created_at', { ascending: false });
  }

  if (params?.limit) {
    query = query.limit(params.limit);
  }

  if (params?.offset) {
    query = query.range(params.offset, params.offset + (params.limit || 10) - 1);
  }

  const { data, error, count } = await query;
  
  if (error) throw error;
  return { products: Array.isArray(data) ? data : [], count: count || 0 };
};

export const getProduct = async (id: string) => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  
  if (error) throw error;
  return data as Product | null;
};

export const createProduct = async (product: Omit<Product, 'id' | 'created_at' | 'rating' | 'review_count'>) => {
  const { data, error } = await supabase
    .from('products')
    .insert(product)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Product;
};

export const updateProduct = async (id: string, updates: Partial<Product>) => {
  const { data, error } = await supabase
    .from('products')
    .update(updates)
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Product;
};

export const deleteProduct = async (id: string) => {
  const { error } = await supabase
    .from('products')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

export const getSellerProducts = async (sellerId: string) => {
  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('seller_id', sellerId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

// ============ Cart ============
export const getCartItems = async (userId: string) => {
  const { data, error } = await supabase
    .from('cart_items')
    .select('*, product:products(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const addToCart = async (userId: string, productId: string, quantity: number = 1) => {
  // Check if item already exists
  const { data: existing } = await supabase
    .from('cart_items')
    .select('*')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();

  if (existing) {
    // Update quantity
    const { data, error } = await supabase
      .from('cart_items')
      .update({ quantity: existing.quantity + quantity })
      .eq('id', existing.id)
      .select()
      .maybeSingle();
    
    if (error) throw error;
    return data as CartItem;
  }

  // Insert new item
  const { data, error } = await supabase
    .from('cart_items')
    .insert({ user_id: userId, product_id: productId, quantity })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as CartItem;
};

export const updateCartItem = async (id: string, quantity: number) => {
  const { data, error } = await supabase
    .from('cart_items')
    .update({ quantity })
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as CartItem;
};

export const removeFromCart = async (id: string) => {
  const { error } = await supabase
    .from('cart_items')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

export const clearCart = async (userId: string) => {
  const { error } = await supabase
    .from('cart_items')
    .delete()
    .eq('user_id', userId);
  
  if (error) throw error;
};

// ============ Wishlist ============
export const getWishlistItems = async (userId: string) => {
  const { data, error } = await supabase
    .from('wishlist_items')
    .select('*, product:products(*)')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const addToWishlist = async (userId: string, productId: string) => {
  const { data, error } = await supabase
    .from('wishlist_items')
    .insert({ user_id: userId, product_id: productId })
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as WishlistItem;
};

export const removeFromWishlist = async (id: string) => {
  const { error } = await supabase
    .from('wishlist_items')
    .delete()
    .eq('id', id);
  
  if (error) throw error;
};

export const isInWishlist = async (userId: string, productId: string) => {
  const { data, error } = await supabase
    .from('wishlist_items')
    .select('id')
    .eq('user_id', userId)
    .eq('product_id', productId)
    .maybeSingle();
  
  if (error) throw error;
  return !!data;
};

// ============ Orders ============
export const getOrders = async (userId: string) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getOrder = async (id: string) => {
  const { data, error } = await supabase
    .from('orders')
    .select('*')
    .eq('id', id)
    .maybeSingle();
  
  if (error) throw error;
  return data as Order | null;
};

export const getOrderItems = async (orderId: string) => {
  const { data, error } = await supabase
    .from('order_items')
    .select('*, product:products(*)')
    .eq('order_id', orderId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createOrder = async (userId: string, total: number, items: { product_id: string; quantity: number; price: number }[]) => {
  // Create order
  const { data: order, error: orderError } = await supabase
    .from('orders')
    .insert({ user_id: userId, total })
    .select()
    .maybeSingle();
  
  if (orderError) throw orderError;
  if (!order) throw new Error('Failed to create order');

  // Create order items
  const orderItems = items.map(item => ({
    order_id: order.id,
    product_id: item.product_id,
    quantity: item.quantity,
    price: item.price,
  }));

  const { error: itemsError } = await supabase
    .from('order_items')
    .insert(orderItems);
  
  if (itemsError) throw itemsError;

  return order as Order;
};

export const updateOrderStatus = async (id: string, status: Order['status']) => {
  const { data, error } = await supabase
    .from('orders')
    .update({ status })
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as Order;
};

// ============ Reviews ============
export const getProductReviews = async (productId: string) => {
  const { data, error } = await supabase
    .from('reviews')
    .select('*, profile:profiles(*)')
    .eq('product_id', productId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const createReview = async (review: Omit<Review, 'id' | 'created_at'>) => {
  const { data, error } = await supabase
    .from('reviews')
    .insert(review)
    .select()
    .maybeSingle();
  
  if (error) throw error;

  // Update product rating
  await updateProductRating(review.product_id);

  return data as Review;
};

export const updateProductRating = async (productId: string) => {
  const reviews = await getProductReviews(productId);
  const avgRating = reviews.length > 0
    ? reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length
    : 0;

  await supabase
    .from('products')
    .update({ rating: Number(avgRating.toFixed(1)), review_count: reviews.length })
    .eq('id', productId);
};

// ============ Support Tickets ============
export const createSupportTicket = async (ticket: Omit<SupportTicket, 'id' | 'created_at' | 'status'>) => {
  const { data, error } = await supabase
    .from('support_tickets')
    .insert(ticket)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as SupportTicket;
};

export const getUserTickets = async (userId: string) => {
  const { data, error } = await supabase
    .from('support_tickets')
    .select('*')
    .eq('user_id', userId)
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const getAllTickets = async () => {
  const { data, error } = await supabase
    .from('support_tickets')
    .select('*')
    .order('created_at', { ascending: false });
  
  if (error) throw error;
  return Array.isArray(data) ? data : [];
};

export const updateTicketStatus = async (id: string, status: TicketStatus) => {
  const { data, error } = await supabase
    .from('support_tickets')
    .update({ status })
    .eq('id', id)
    .select()
    .maybeSingle();
  
  if (error) throw error;
  return data as SupportTicket;
};

// ============ Brands ============
export const getBrands = async () => {
  const { data, error } = await supabase
    .from('products')
    .select('brand')
    .not('brand', 'is', null)
    .order('brand');
  
  if (error) throw error;
  
  const brands = Array.isArray(data) ? [...new Set(data.map(p => p.brand).filter(Boolean))] : [];
  return brands as string[];
};
