import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getAllProfiles, updateProfile } from '@/db/api';
import type { Profile } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export default function AdminPage() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const { user, profile } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }
    if (profile?.role !== 'admin') {
      toast.error('Admin access required');
      navigate('/');
      return;
    }
    loadProfiles();
  }, [user, profile]);

  const loadProfiles = async () => {
    try {
      const data = await getAllProfiles();
      setProfiles(data);
    } catch (error) {
      toast.error('Failed to load profiles');
    }
  };

  const handleRoleChange = async (userId: string, role: Profile['role']) => {
    try {
      await updateProfile(userId, { role });
      await loadProfiles();
      toast.success('Role updated');
    } catch (error) {
      toast.error('Failed to update role');
    }
  };

  return (
    <div className="container px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Admin Panel</h1>
      <Card>
        <CardHeader><CardTitle>User Management</CardTitle></CardHeader>
        <CardContent>
          <div className="space-y-4">
            {profiles.map((p) => (
              <div key={p.id} className="flex items-center justify-between p-4 border rounded">
                <div>
                  <p className="font-semibold">{p.username}</p>
                  <p className="text-sm text-muted-foreground">{p.email}</p>
                </div>
                <Select value={p.role} onValueChange={(v) => handleRoleChange(p.id, v as Profile['role'])}>
                  <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">User</SelectItem>
                    <SelectItem value="seller">Seller</SelectItem>
                    <SelectItem value="admin">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
