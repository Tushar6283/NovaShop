import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ProductCard } from '@/components/products/ProductCard';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { getProducts, addToCart, addToWishlist, removeFromWishlist, isInWishlist, getWishlistItems } from '@/db/api';
import type { Product } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Search } from 'lucide-react';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState(searchParams.get('q') || '');
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    const query = searchParams.get('q');
    if (query) {
      setSearchQuery(query);
      performSearch(query);
    }
  }, [searchParams, user]);

  const performSearch = async (query: string) => {
    try {
      setLoading(true);
      const { products: results } = await getProducts({ search: query });
      setProducts(results);

      if (user) {
        const wishlistPromises = results.map(p =>
          isInWishlist(user.id, p.id).then(inList => ({ id: p.id, inList }))
        );
        const wishlistResults = await Promise.all(wishlistPromises);
        setWishlistIds(new Set(wishlistResults.filter(r => r.inList).map(r => r.id)));
      }
    } catch (error) {
      toast.error('Search failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery.trim())}`);
    }
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in');
      navigate('/login');
      return;
    }
    try {
      await addToCart(user.id, product.id, 1);
      toast.success('Added to cart');
    } catch (error) {
      toast.error('Failed to add to cart');
    }
  };

  const handleToggleWishlist = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in');
      navigate('/login');
      return;
    }
    try {
      if (wishlistIds.has(product.id)) {
        const items = await getWishlistItems(user.id);
        const item = items.find(i => i.product_id === product.id);
        if (item) {
          await removeFromWishlist(item.id);
          setWishlistIds(prev => {
            const next = new Set(prev);
            next.delete(product.id);
            return next;
          });
          toast.success('Removed from wishlist');
        }
      } else {
        await addToWishlist(user.id, product.id);
        setWishlistIds(prev => new Set(prev).add(product.id));
        toast.success('Added to wishlist');
      }
    } catch (error) {
      toast.error('Failed to update wishlist');
    }
  };

  return (
    <div className="container px-4 py-8">
      <form onSubmit={handleSearch} className="max-w-2xl mx-auto mb-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search products..."
            className="pl-10 pr-4 h-12 text-lg"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
      </form>

      {loading ? (
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
        </div>
      ) : (
        <>
          <h2 className="text-2xl font-bold mb-6">
            {products.length} results for "{searchParams.get('q')}"
          </h2>
          {products.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No products found</p>
              <Button onClick={() => navigate('/products')}>Browse all products</Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onToggleWishlist={handleToggleWishlist}
                  isInWishlist={wishlistIds.has(product.id)}
                />
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
