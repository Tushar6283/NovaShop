import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getOrders, getOrderItems, updateOrderStatus, addToCart } from '@/db/api';
import type { Order, OrderItem } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Package, ChevronDown, ChevronUp } from 'lucide-react';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [orderItems, setOrderItems] = useState<Record<string, OrderItem[]>>({});
  const [expandedOrders, setExpandedOrders] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadOrders();
    } else {
      navigate('/login');
    }
  }, [user]);

  const loadOrders = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const data = await getOrders(user.id);
      setOrders(data);
    } catch (error) {
      toast.error('Failed to load orders');
    } finally {
      setLoading(false);
    }
  };

  const loadOrderItems = async (orderId: string) => {
    try {
      const items = await getOrderItems(orderId);
      setOrderItems(prev => ({ ...prev, [orderId]: items }));
    } catch (error) {
      toast.error('Failed to load order items');
    }
  };

  const toggleOrder = (orderId: string) => {
    const newExpanded = new Set(expandedOrders);
    if (newExpanded.has(orderId)) {
      newExpanded.delete(orderId);
    } else {
      newExpanded.add(orderId);
      if (!orderItems[orderId]) {
        loadOrderItems(orderId);
      }
    }
    setExpandedOrders(newExpanded);
  };

  const handleBuyAgain = async (items: OrderItem[]) => {
    if (!user) return;
    try {
      for (const item of items) {
        if (item.product_id) {
          await addToCart(user.id, item.product_id, item.quantity);
        }
      }
      toast.success('Items added to cart');
      navigate('/cart');
    } catch (error) {
      toast.error('Failed to add items to cart');
    }
  };

  const handleCancelOrder = async (orderId: string) => {
    try {
      await updateOrderStatus(orderId, 'cancelled');
      await loadOrders();
      toast.success('Order cancelled');
    } catch (error) {
      toast.error('Failed to cancel order');
    }
  };

  const getStatusColor = (status: Order['status']) => {
    switch (status) {
      case 'delivered': return 'default';
      case 'shipped': return 'secondary';
      case 'processing': return 'secondary';
      case 'cancelled': return 'destructive';
      default: return 'secondary';
    }
  };

  if (loading) {
    return <div className="container px-4 py-8"><div className="flex items-center justify-center min-h-[400px]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div></div>;
  }

  if (orders.length === 0) {
    return (
      <div className="container px-4 py-8">
        <div className="max-w-md mx-auto text-center py-12">
          <Package className="h-24 w-24 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-2xl font-bold mb-2">No orders yet</h2>
          <p className="text-muted-foreground mb-6">Start shopping to see your orders here</p>
          <Button onClick={() => navigate('/products')}>Browse Products</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Orders</h1>
      <div className="space-y-4">
        {orders.map((order) => (
          <Card key={order.id}>
            <Collapsible open={expandedOrders.has(order.id)} onOpenChange={() => toggleOrder(order.id)}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">Order #{order.id.slice(0, 8)}</CardTitle>
                    <p className="text-sm text-muted-foreground">{new Date(order.created_at).toLocaleDateString()}</p>
                  </div>
                  <div className="flex items-center gap-4">
                    <Badge variant={getStatusColor(order.status)}>{order.status}</Badge>
                    <span className="text-lg font-bold">${order.total.toFixed(2)}</span>
                    <CollapsibleTrigger asChild>
                      <Button variant="ghost" size="icon">
                        {expandedOrders.has(order.id) ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
                      </Button>
                    </CollapsibleTrigger>
                  </div>
                </div>
              </CardHeader>
              <CollapsibleContent>
                <CardContent>
                  <div className="space-y-4">
                    {orderItems[order.id]?.map((item) => (
                      <div key={item.id} className="flex gap-4 items-center">
                        <img src={item.product?.images?.[0] || ''} alt={item.product?.name} className="w-16 h-16 object-cover rounded" />
                        <div className="flex-1">
                          <p className="font-semibold">{item.product?.name}</p>
                          <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                        </div>
                        <span className="font-bold">${(item.price * item.quantity).toFixed(2)}</span>
                      </div>
                    ))}
                    <div className="flex gap-2 pt-4">
                      <Button onClick={() => handleBuyAgain(orderItems[order.id] || [])}>Buy Again</Button>
                      {order.status === 'pending' && (
                        <Button variant="outline" onClick={() => handleCancelOrder(order.id)}>Cancel Order</Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </CollapsibleContent>
            </Collapsible>
          </Card>
        ))}
      </div>
    </div>
  );
}
