export default function AboutPage() {
  return (
    <div className="container px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">About NovaShop</h1>
        <div className="prose max-w-none space-y-4 text-muted-foreground">
          <p>NovaShop is your premier destination for premium electronics and tech products. Founded in 2026, we've built a reputation for quality, reliability, and exceptional customer service.</p>
          <p>Our mission is to make cutting-edge technology accessible to everyone. We carefully curate our product selection to ensure you get the best value for your money.</p>
          <p>With fast shipping, easy returns, and dedicated support, shopping with NovaShop is always a pleasure.</p>
        </div>
      </div>
    </div>
  );
}
