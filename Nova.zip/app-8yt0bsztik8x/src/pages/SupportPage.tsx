import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { createSupportTicket } from '@/db/api';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export default function SupportPage() {
  const [formData, setFormData] = useState({ name: '', email: '', subject: '', message: '' });
  const { user, profile } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createSupportTicket({
        user_id: user?.id || null,
        name: formData.name || profile?.username || 'Guest',
        email: formData.email || profile?.email || '',
        subject: formData.subject,
        message: formData.message,
      });
      toast.success('Support ticket submitted');
      setFormData({ name: '', email: '', subject: '', message: '' });
    } catch (error) {
      toast.error('Failed to submit ticket');
    }
  };

  return (
    <div className="container px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Customer Support</h1>
      <div className="grid xl:grid-cols-2 gap-8">
        <Card>
          <CardHeader><CardTitle>Contact Us</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div><Label htmlFor="name">Name</Label><Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} required /></div>
              <div><Label htmlFor="email">Email</Label><Input id="email" type="email" value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} required /></div>
              <div><Label htmlFor="subject">Subject</Label><Input id="subject" value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })} required /></div>
              <div><Label htmlFor="message">Message</Label><Textarea id="message" value={formData.message} onChange={(e) => setFormData({ ...formData, message: e.target.value })} rows={5} required /></div>
              <Button type="submit" className="w-full">Submit</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>Frequently Asked Questions</CardTitle></CardHeader>
          <CardContent>
            <Accordion type="single" collapsible>
              <AccordionItem value="1"><AccordionTrigger>How do I track my order?</AccordionTrigger><AccordionContent>You can track your order from the Orders page in your account.</AccordionContent></AccordionItem>
              <AccordionItem value="2"><AccordionTrigger>What is your return policy?</AccordionTrigger><AccordionContent>We offer a 30-day return policy for most items. See our Returns page for details.</AccordionContent></AccordionItem>
              <AccordionItem value="3"><AccordionTrigger>Do you offer international shipping?</AccordionTrigger><AccordionContent>Yes, we ship to most countries worldwide. Shipping costs vary by location.</AccordionContent></AccordionItem>
              <AccordionItem value="4"><AccordionTrigger>How can I become a seller?</AccordionTrigger><AccordionContent>Contact us through this form and we'll help you get started as a seller on NovaShop.</AccordionContent></AccordionItem>
            </Accordion>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
