import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ProductCard } from '@/components/products/ProductCard';
import { Button } from '@/components/ui/button';
import { getWishlistItems, removeFromWishlist, addToCart } from '@/db/api';
import type { WishlistItem } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Heart } from 'lucide-react';

export default function WishlistPage() {
  const [items, setItems] = useState<WishlistItem[]>([]);
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      loadWishlist();
    } else {
      navigate('/login');
    }
  }, [user]);

  const loadWishlist = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const data = await getWishlistItems(user.id);
      setItems(data);
    } catch (error) {
      toast.error('Failed to load wishlist');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async (productId: string) => {
    if (!user) return;
    try {
      await addToCart(user.id, productId, 1);
      toast.success('Added to cart');
    } catch (error) {
      toast.error('Failed to add to cart');
    }
  };

  const handleRemove = async (itemId: string) => {
    try {
      await removeFromWishlist(itemId);
      await loadWishlist();
      toast.success('Removed from wishlist');
    } catch (error) {
      toast.error('Failed to remove item');
    }
  };

  if (loading) {
    return <div className="container px-4 py-8"><div className="flex items-center justify-center min-h-[400px]"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div></div></div>;
  }

  if (items.length === 0) {
    return (
      <div className="container px-4 py-8">
        <div className="max-w-md mx-auto text-center py-12">
          <Heart className="h-24 w-24 mx-auto mb-4 text-muted-foreground" />
          <h2 className="text-2xl font-bold mb-2">Your wishlist is empty</h2>
          <p className="text-muted-foreground mb-6">Save items you love for later</p>
          <Button onClick={() => navigate('/products')}>Browse Products</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="container px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">My Wishlist</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {items.map((item) => item.product && (
          <ProductCard
            key={item.id}
            product={item.product}
            onAddToCart={() => handleAddToCart(item.product_id)}
            onToggleWishlist={() => handleRemove(item.id)}
            isInWishlist={true}
          />
        ))}
      </div>
    </div>
  );
}
