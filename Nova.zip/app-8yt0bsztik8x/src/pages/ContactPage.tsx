export default function ContactPage() {
  return (
    <div className="container px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Contact Us</h1>
        <div className="space-y-6">
          <div><h2 className="text-xl font-semibold mb-2">Email</h2><p className="text-muted-foreground">support@novashop.com</p></div>
          <div><h2 className="text-xl font-semibold mb-2">Phone</h2><p className="text-muted-foreground">1-800-NOVA-SHOP</p></div>
          <div><h2 className="text-xl font-semibold mb-2">Address</h2><p className="text-muted-foreground">123 Tech Street, Silicon Valley, CA 94000</p></div>
          <div><h2 className="text-xl font-semibold mb-2">Business Hours</h2><p className="text-muted-foreground">Monday - Friday: 9AM - 6PM PST<br />Saturday - Sunday: 10AM - 4PM PST</p></div>
        </div>
      </div>
    </div>
  );
}
