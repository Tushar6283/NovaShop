import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Carousel, CarouselContent, CarouselItem, CarouselNext, CarouselPrevious } from '@/components/ui/carousel';
import { ProductCard } from '@/components/products/ProductCard';
import { Skeleton } from '@/components/ui/skeleton';
import { getProducts, getCategories, addToCart, addToWishlist, removeFromWishlist, isInWishlist } from '@/db/api';
import type { Product, Category } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { ArrowRight, Sparkles, TrendingUp, Tag, Zap, Gift, Star, Clock, Percent } from 'lucide-react';

export default function HomePage() {
  const [featuredProducts, setFeaturedProducts] = useState<Product[]>([]);
  const [trendingProducts, setTrendingProducts] = useState<Product[]>([]);
  const [bestsellerProducts, setBestsellerProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [productsRes, categoriesData] = await Promise.all([
        getProducts({ limit: 20, sortBy: 'newest' }),
        getCategories(),
      ]);

      setFeaturedProducts(productsRes.products.slice(0, 8));
      setTrendingProducts(productsRes.products.slice(8, 16));
      setBestsellerProducts(productsRes.products.slice(16, 20));
      setCategories(categoriesData);

      if (user) {
        const wishlistPromises = productsRes.products.map(p =>
          isInWishlist(user.id, p.id).then(inList => ({ id: p.id, inList }))
        );
        const wishlistResults = await Promise.all(wishlistPromises);
        setWishlistIds(new Set(wishlistResults.filter(r => r.inList).map(r => r.id)));
      }
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in to add items to cart');
      navigate('/login');
      return;
    }

    try {
      await addToCart(user.id, product.id, 1);
      toast.success('Added to cart');
    } catch (error) {
      toast.error('Failed to add to cart');
    }
  };

  const handleToggleWishlist = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in to add items to wishlist');
      navigate('/login');
      return;
    }

    try {
      if (wishlistIds.has(product.id)) {
        const items = await import('@/db/api').then(m => m.getWishlistItems(user.id));
        const item = items.find(i => i.product_id === product.id);
        if (item) {
          await removeFromWishlist(item.id);
          setWishlistIds(prev => {
            const next = new Set(prev);
            next.delete(product.id);
            return next;
          });
          toast.success('Removed from wishlist');
        }
      } else {
        await addToWishlist(user.id, product.id);
        setWishlistIds(prev => new Set(prev).add(product.id));
        toast.success('Added to wishlist');
      }
    } catch (error) {
      toast.error('Failed to update wishlist');
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/10 via-background to-secondary/10 py-16 xl:py-28">
        {/* Decorative Elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-secondary/10 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        </div>
        
        <div className="container px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-primary/10 backdrop-blur-sm border border-primary/20 text-primary text-sm font-medium mb-8 shadow-glow animate-bounce">
              <Sparkles className="h-4 w-4 animate-pulse" />
              New Arrivals Just Dropped!
            </div>
            <h1 className="text-4xl xl:text-7xl font-bold mb-6 gradient-text-animated leading-tight">
              Discover Your Perfect Style
            </h1>
            <p className="text-lg xl:text-xl text-muted-foreground mb-10 max-w-2xl mx-auto leading-relaxed">
              Shop the latest trends with exclusive deals and free shipping on orders over $50. 
              Quality products, unbeatable prices, and exceptional service.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <Button size="lg" className="shadow-colorful hover:shadow-glow-lg text-base px-8" onClick={() => navigate('/products')}>
                Shop Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="text-base px-8 border-2 hover-glow" onClick={() => navigate('/products?sortBy=newest')}>
                View New Arrivals
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-6 max-w-2xl mx-auto">
              <div className="text-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border hover-lift hover-glow smooth-transition">
                <div className="text-3xl font-bold gradient-text mb-1">10K+</div>
                <div className="text-sm text-muted-foreground">Products</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border hover-lift hover-glow smooth-transition">
                <div className="text-3xl font-bold gradient-text mb-1">50K+</div>
                <div className="text-sm text-muted-foreground">Happy Customers</div>
              </div>
              <div className="text-center p-4 rounded-xl bg-card/50 backdrop-blur-sm border border-border hover-lift hover-glow smooth-transition">
                <div className="text-3xl font-bold gradient-text mb-1">4.8★</div>
                <div className="text-sm text-muted-foreground">Average Rating</div>
              </div>
            </div>
          </div>
        </div>
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-border to-transparent" />
      </section>

      {/* Categories Carousel */}
      <section className="py-16 border-b bg-muted/30">
        <div className="container px-4">
          <div className="mb-8">
            <h2 className="text-3xl font-bold mb-2">Shop by Category</h2>
            <p className="text-muted-foreground">Explore our wide range of product categories</p>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-6 gap-4">
              {[...Array(6)].map((_, i) => (
                <Skeleton key={i} className="h-36 bg-muted rounded-xl" />
              ))}
            </div>
          ) : (
            <Carousel opts={{ align: 'start' }} className="w-full">
              <CarouselContent className="-ml-4">
                {categories.map((category) => (
                  <CarouselItem key={category.id} className="pl-4 basis-1/2 md:basis-1/4 xl:basis-1/6">
                    <button
                      onClick={() => navigate(`/products?category=${category.slug}`)}
                      className="w-full p-6 rounded-xl border-2 bg-card hover:bg-accent hover:border-primary/50 hover:shadow-glow transition-all duration-300 text-center group hover-scale"
                    >
                      <div className="text-5xl mb-3 group-hover:scale-110 transition-transform duration-300 bounce-subtle">{category.icon}</div>
                      <h3 className="font-semibold text-sm group-hover:text-primary transition-colors">{category.name}</h3>
                    </button>
                  </CarouselItem>
                ))}
              </CarouselContent>
              <CarouselPrevious className="hidden xl:flex" />
              <CarouselNext className="hidden xl:flex" />
            </Carousel>
          )}
        </div>
      </section>

      {/* Promotional Banner 1 */}
      <section className="py-8 bg-gradient-to-r from-primary/10 via-secondary/10 to-accent/10">
        <div className="container px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-2 border-primary/20 hover:border-primary/40 transition-all cursor-pointer group hover-lift hover:shadow-glow shimmer" onClick={() => navigate('/products')}>
              <CardContent className="p-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:scale-110 transition-transform bounce-subtle">
                  <Zap className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Flash Deals</h3>
                  <p className="text-sm text-muted-foreground">Up to 50% off</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-secondary/20 hover:border-secondary/40 transition-all cursor-pointer group hover-lift hover:shadow-glow-secondary shimmer" onClick={() => navigate('/products')}>
              <CardContent className="p-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-secondary/10 flex items-center justify-center group-hover:scale-110 transition-transform bounce-subtle" style={{ animationDelay: '0.3s' }}>
                  <Gift className="h-6 w-6 text-secondary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Free Shipping</h3>
                  <p className="text-sm text-muted-foreground">On orders over $50</p>
                </div>
              </CardContent>
            </Card>

            <Card className="border-2 border-accent/20 hover:border-accent/40 transition-all cursor-pointer group hover-lift hover:shadow-glow shimmer" onClick={() => navigate('/products')}>
              <CardContent className="p-6 flex items-center gap-4">
                <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center group-hover:scale-110 transition-transform bounce-subtle" style={{ animationDelay: '0.6s' }}>
                  <Percent className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg mb-1">Member Deals</h3>
                  <p className="text-sm text-muted-foreground">Exclusive discounts</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-16">
        <div className="container px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-primary/10">
                  <Tag className="h-5 w-5 text-primary" />
                </div>
                <h2 className="text-3xl font-bold">Featured Products</h2>
              </div>
              <p className="text-muted-foreground">Handpicked items just for you</p>
            </div>
            <Button variant="ghost" className="hidden xl:flex" onClick={() => navigate('/products')}>
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-[340px] bg-muted rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {featuredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onToggleWishlist={handleToggleWishlist}
                  isInWishlist={wishlistIds.has(product.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Trending Products */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-secondary/10">
                  <TrendingUp className="h-5 w-5 text-secondary" />
                </div>
                <h2 className="text-3xl font-bold">Trending Now</h2>
              </div>
              <p className="text-muted-foreground">Most popular products this week</p>
            </div>
            <Button variant="ghost" className="hidden xl:flex" onClick={() => navigate('/products?sortBy=rating')}>
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => (
                <Skeleton key={i} className="h-[340px] bg-muted rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {trendingProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onToggleWishlist={handleToggleWishlist}
                  isInWishlist={wishlistIds.has(product.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Special Offers Banner */}
      <section className="py-12 bg-gradient-to-br from-secondary/20 via-background to-primary/20">
        <div className="container px-4">
          <div className="max-w-4xl mx-auto text-center">
            <Badge className="mb-4 bg-secondary text-secondary-foreground px-4 py-1 text-sm">
              <Clock className="h-3 w-3 mr-1 inline" />
              Limited Time Offer
            </Badge>
            <h2 className="text-4xl font-bold mb-4 gradient-text">
              Weekend Special Sale
            </h2>
            <p className="text-lg text-muted-foreground mb-6">
              Get up to 40% off on selected items. Hurry, offer ends soon!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="shadow-lg hover:shadow-xl transition-shadow" onClick={() => navigate('/products')}>
                Shop Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
              <Button size="lg" variant="outline" className="border-2" onClick={() => navigate('/products?sortBy=price')}>
                View All Deals
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Bestsellers Section */}
      <section className="py-16">
        <div className="container px-4">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <div className="p-2 rounded-lg bg-secondary/10">
                  <Star className="h-5 w-5 text-secondary" />
                </div>
                <h2 className="text-3xl font-bold">Bestsellers</h2>
              </div>
              <p className="text-muted-foreground">Customer favorites and top-rated products</p>
            </div>
            <Button variant="ghost" className="hidden xl:flex" onClick={() => navigate('/products?sortBy=rating')}>
              View All
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </div>
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-2 xl:grid-cols-4 gap-4">
              {[...Array(4)].map((_, i) => (
                <Skeleton key={i} className="h-[340px] bg-muted rounded-xl" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-2 xl:grid-cols-4 gap-4">
              {bestsellerProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onToggleWishlist={handleToggleWishlist}
                  isInWishlist={wishlistIds.has(product.id)}
                />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-muted/30">
        <div className="container px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-3">Why Choose NovaShop?</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              We're committed to providing the best shopping experience with quality products and exceptional service
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Zap className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Fast Delivery</h3>
                <p className="text-sm text-muted-foreground">
                  Quick and reliable shipping to your doorstep
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="h-16 w-16 rounded-full bg-secondary/10 flex items-center justify-center mx-auto mb-4">
                  <Star className="h-8 w-8 text-secondary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Quality Products</h3>
                <p className="text-sm text-muted-foreground">
                  Carefully curated selection of premium items
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Gift className="h-8 w-8 text-primary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Great Deals</h3>
                <p className="text-sm text-muted-foreground">
                  Exclusive offers and competitive prices
                </p>
              </CardContent>
            </Card>

            <Card className="text-center hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="h-16 w-16 rounded-full bg-secondary/10 flex items-center justify-center mx-auto mb-4">
                  <Sparkles className="h-8 w-8 text-secondary" />
                </div>
                <h3 className="font-semibold text-lg mb-2">24/7 Support</h3>
                <p className="text-sm text-muted-foreground">
                  Always here to help with your questions
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-primary to-secondary text-primary-foreground">
        <div className="container px-4 text-center">
          <h2 className="text-3xl xl:text-4xl font-bold mb-4">
            Start Selling on NovaShop
          </h2>
          <p className="text-lg mb-8 opacity-90 max-w-2xl mx-auto">
            Join thousands of sellers and reach millions of customers. Easy setup, powerful tools, and great support.
          </p>
          <Button size="lg" variant="secondary" onClick={() => navigate('/seller')}>
            Become a Seller
          </Button>
        </div>
      </section>
    </div>
  );
}
