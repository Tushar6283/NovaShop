export default function ShippingPage() {
  return (
    <div className="container px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Shipping Information</h1>
        <div className="prose max-w-none space-y-4 text-muted-foreground">
          <h2 className="text-2xl font-semibold text-foreground">Shipping Methods</h2>
          <p>We offer standard and express shipping options. Free shipping on orders over $50.</p>
          <h2 className="text-2xl font-semibold text-foreground mt-6">Delivery Times</h2>
          <p>Standard: 5-7 business days<br />Express: 2-3 business days</p>
          <h2 className="text-2xl font-semibold text-foreground mt-6">International Shipping</h2>
          <p>We ship to most countries worldwide. International delivery times vary by location.</p>
        </div>
      </div>
    </div>
  );
}
