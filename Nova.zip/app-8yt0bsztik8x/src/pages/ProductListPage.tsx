import { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { ProductCard } from '@/components/products/ProductCard';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { getProducts, getBrands, addToCart, addToWishlist, removeFromWishlist, isInWishlist, getWishlistItems } from '@/db/api';
import type { Product } from '@/types';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { SlidersHorizontal, Grid3x3, List } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';

export default function ProductListPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [brands, setBrands] = useState<string[]>([]);
  const [wishlistIds, setWishlistIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const { user } = useAuth();
  const navigate = useNavigate();

  const category = searchParams.get('category') || '';
  const sortBy = searchParams.get('sortBy') || 'newest';
  const minPrice = Number(searchParams.get('minPrice')) || 0;
  const maxPrice = Number(searchParams.get('maxPrice')) || 5000;
  const selectedBrands = searchParams.get('brands')?.split(',').filter(Boolean) || [];
  const minRating = Number(searchParams.get('minRating')) || 0;

  useEffect(() => {
    loadProducts();
  }, [searchParams, user]);

  useEffect(() => {
    getBrands().then(setBrands).catch(() => setBrands([]));
  }, []);

  const loadProducts = async () => {
    try {
      setLoading(true);
      const { products: productsData } = await getProducts({
        category,
        sortBy: sortBy as any,
        minPrice: minPrice || undefined,
        maxPrice: maxPrice < 5000 ? maxPrice : undefined,
        brand: selectedBrands[0] || undefined,
        minRating: minRating || undefined,
      });

      setProducts(productsData);

      if (user) {
        const wishlistPromises = productsData.map(p =>
          isInWishlist(user.id, p.id).then(inList => ({ id: p.id, inList }))
        );
        const wishlistResults = await Promise.all(wishlistPromises);
        setWishlistIds(new Set(wishlistResults.filter(r => r.inList).map(r => r.id)));
      }
    } catch (error) {
      console.error('Failed to load products:', error);
      toast.error('Failed to load products');
    } finally {
      setLoading(false);
    }
  };

  const updateFilter = (key: string, value: string | number | string[]) => {
    const params = new URLSearchParams(searchParams);
    if (value === '' || value === 0 || (Array.isArray(value) && value.length === 0)) {
      params.delete(key);
    } else {
      params.set(key, String(value));
    }
    setSearchParams(params);
  };

  const handleAddToCart = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in to add items to cart');
      navigate('/login');
      return;
    }

    try {
      await addToCart(user.id, product.id, 1);
      toast.success('Added to cart');
    } catch (error) {
      toast.error('Failed to add to cart');
    }
  };

  const handleToggleWishlist = async (product: Product) => {
    if (!user) {
      toast.error('Please sign in to add items to wishlist');
      navigate('/login');
      return;
    }

    try {
      if (wishlistIds.has(product.id)) {
        const items = await getWishlistItems(user.id);
        const item = items.find(i => i.product_id === product.id);
        if (item) {
          await removeFromWishlist(item.id);
          setWishlistIds(prev => {
            const next = new Set(prev);
            next.delete(product.id);
            return next;
          });
          toast.success('Removed from wishlist');
        }
      } else {
        await addToWishlist(user.id, product.id);
        setWishlistIds(prev => new Set(prev).add(product.id));
        toast.success('Added to wishlist');
      }
    } catch (error) {
      toast.error('Failed to update wishlist');
    }
  };

  const FilterPanel = () => (
    <div className="space-y-6">
      <div>
        <h3 className="font-semibold mb-3">Price Range</h3>
        <Slider
          value={[minPrice, maxPrice]}
          onValueChange={([min, max]) => {
            updateFilter('minPrice', min);
            updateFilter('maxPrice', max);
          }}
          max={5000}
          step={50}
          className="mb-2"
        />
        <div className="flex justify-between text-sm text-muted-foreground">
          <span>${minPrice}</span>
          <span>${maxPrice}</span>
        </div>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Minimum Rating</h3>
        <Select value={String(minRating)} onValueChange={(v) => updateFilter('minRating', Number(v))}>
          <SelectTrigger>
            <SelectValue placeholder="Any rating" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="0">Any rating</SelectItem>
            <SelectItem value="4">4+ stars</SelectItem>
            <SelectItem value="4.5">4.5+ stars</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div>
        <h3 className="font-semibold mb-3">Brands</h3>
        <div className="space-y-2 max-h-48 overflow-auto">
          {brands.slice(0, 10).map((brand) => (
            <div key={brand} className="flex items-center space-x-2">
              <Checkbox
                id={brand}
                checked={selectedBrands.includes(brand)}
                onCheckedChange={(checked) => {
                  const newBrands = checked
                    ? [...selectedBrands, brand]
                    : selectedBrands.filter(b => b !== brand);
                  updateFilter('brands', newBrands.join(','));
                }}
              />
              <Label htmlFor={brand} className="text-sm cursor-pointer">
                {brand}
              </Label>
            </div>
          ))}
        </div>
      </div>

      <Button
        variant="outline"
        className="w-full"
        onClick={() => {
          setSearchParams(new URLSearchParams(category ? { category } : {}));
        }}
      >
        Clear Filters
      </Button>
    </div>
  );

  return (
    <div className="container px-4 py-8">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-bold mb-2">
            {category ? category.charAt(0).toUpperCase() + category.slice(1).replace('-', ' ') : 'All Products'}
          </h1>
          <p className="text-muted-foreground">{products.length} products found</p>
        </div>
        <div className="flex items-center gap-2">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="xl:hidden">
                <SlidersHorizontal className="h-4 w-4" />
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="mt-6">
                <FilterPanel />
              </div>
            </SheetContent>
          </Sheet>

          <Select value={sortBy} onValueChange={(v) => updateFilter('sortBy', v)}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="newest">Newest</SelectItem>
              <SelectItem value="price_asc">Price: Low to High</SelectItem>
              <SelectItem value="price_desc">Price: High to Low</SelectItem>
              <SelectItem value="rating">Highest Rated</SelectItem>
            </SelectContent>
          </Select>

          <div className="hidden md:flex gap-1">
            <Button
              variant={viewMode === 'grid' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('grid')}
            >
              <Grid3x3 className="h-4 w-4" />
            </Button>
            <Button
              variant={viewMode === 'list' ? 'default' : 'outline'}
              size="icon"
              onClick={() => setViewMode('list')}
            >
              <List className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <div className="flex gap-6">
        {/* Desktop Filters */}
        <aside className="hidden xl:block w-64 shrink-0">
          <div className="sticky top-20">
            <FilterPanel />
          </div>
        </aside>

        {/* Products Grid */}
        <div className="flex-1">
          {loading ? (
            <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
              {[...Array(12)].map((_, i) => (
                <Skeleton key={i} className="h-[340px] bg-muted rounded-xl" />
              ))}
            </div>
          ) : products.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-muted-foreground mb-4">No products found</p>
              <Button onClick={() => setSearchParams(new URLSearchParams())}>
                Clear all filters
              </Button>
            </div>
          ) : (
            <div className={viewMode === 'grid' ? 'grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4' : 'space-y-4'}>
              {products.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  onAddToCart={handleAddToCart}
                  onToggleWishlist={handleToggleWishlist}
                  isInWishlist={wishlistIds.has(product.id)}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
