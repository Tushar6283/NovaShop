export default function ReturnsPage() {
  return (
    <div className="container px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">Returns & Exchanges</h1>
        <div className="prose max-w-none space-y-4 text-muted-foreground">
          <h2 className="text-2xl font-semibold text-foreground">30-Day Return Policy</h2>
          <p>We accept returns within 30 days of purchase for most items in original condition.</p>
          <h2 className="text-2xl font-semibold text-foreground mt-6">How to Return</h2>
          <p>Contact our support team to initiate a return. We'll provide a prepaid shipping label.</p>
          <h2 className="text-2xl font-semibold text-foreground mt-6">Refunds</h2>
          <p>Refunds are processed within 5-7 business days after we receive your return.</p>
        </div>
      </div>
    </div>
  );
}
